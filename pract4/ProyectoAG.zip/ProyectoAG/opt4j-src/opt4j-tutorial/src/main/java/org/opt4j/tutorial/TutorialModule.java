package org.opt4j.tutorial;

import org.opt4j.core.config.Icons;
import org.opt4j.core.config.annotations.Category;
import org.opt4j.core.config.annotations.Icon;

@Category
@Icon(Icons.HELP)
public final class TutorialModule {

}
